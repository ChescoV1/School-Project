﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace School_Project
{
    public partial class Home : Form
    {
        private string saveFile = "tasks.txt";
        public Home()
        {
            InitializeComponent();
            LoadTasks();
            Settings.Visible = false;
        }
        private void LoadTasks()
        {
            if (File.Exists(saveFile))
            {
                string[] lines = File.ReadAllLines(saveFile);
                foreach (string line in lines)
                {
                    Tasks.Items.Add(line);
                }
            }
        }
        private void SaveTasks()
        {
            File.WriteAllLines(saveFile, GetTasksArray());
        }
        private string[] GetTasksArray()
        {
            string[] tasks = new string[Tasks.Items.Count];
            for (int i = 0; i < Tasks.Items.Count; i++)
            {
                tasks[i] = Tasks.Items[i].ToString();
            }
            return tasks;
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
                PlaySound("open.wav");
                formShadow.SetShadowForm(this);
                string userName = Environment.UserName;
                Welcome.Text = $"Welcome, {userName}!";
            }
        
        private void PlaySound(string soundFile)
        {
            try
            {
                SoundPlayer player = new SoundPlayer(soundFile);
                player.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error playing sound: " + ex.Message);
            }
        }
        private void guna2Button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void buttonAddTask_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBoxNewTask.Text))
            {
                Tasks.Items.Add(textBoxNewTask.Text);
                textBoxNewTask.Clear();
                SaveTasks();
            }
        }

        private void buttonRemoveTask_Click(object sender, EventArgs e)
        {
            for (int i = Tasks.CheckedItems.Count - 1; i >= 0; i--)
            {
                Tasks.Items.Remove(Tasks.CheckedItems[i]);
            }
            SaveTasks();
        }

        private void guna2CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            this.TopMost = this.checkBoxTopMost.Checked;
        }


        private void guna2Button3_Click(object sender, EventArgs e)
        {
            AboutMe newForm = new AboutMe();
            newForm.Show();
            this.Hide();
        }

        private void guna2CheckBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            ToggleDarkMode(checkBoxDarkMode.Checked);
        }
        private void ToggleDarkMode(bool darkMode)
        {
            if (darkMode)
            {
                Clear.Visible = true;
                this.BackColor = Color.FromArgb(45, 45, 48); // Dark gray
                Tasks.BackColor = Color.FromArgb(45, 45, 48);
                Tasks.ForeColor = Color.White;
                textBoxNewTask.PlaceholderForeColor = Color.White;
                textBoxNewTask.ForeColor = Color.White;
                textBoxNewTask.FillColor = Color.FromArgb(45, 45, 48);
                textBoxNewTask.BorderColor = Color.FromArgb(45, 45, 48);
                btnCredits.ForeColor = Color.White;
                Welcome.ForeColor = Color.White;
                textBoxNewTask.BackColor = Color.FromArgb(45, 45, 48);
                textBoxNewTask.ForeColor = Color.Black;
                buttonAddTask.BackColor = Color.FromArgb(45, 45, 48);
                buttonAddTask.ForeColor = Color.White;
                buttonRemoveTask.BackColor = Color.FromArgb(45, 45, 48);
                buttonRemoveTask.ForeColor = Color.White;
                btnSettings.ForeColor = Color.White;
            }
            else
            {
                this.BackColor = SystemColors.Control; // Light mode
                Tasks.BackColor = Color.White;
                Tasks.ForeColor = Color.Black;
                textBoxNewTask.PlaceholderForeColor = Color.Black;
                textBoxNewTask.ForeColor = Color.Black;
                textBoxNewTask.FillColor = Color.White;
                btnCredits.ForeColor = Color.Black;
                Welcome.ForeColor = Color.Black;
                textBoxNewTask.BackColor = Color.White;
                textBoxNewTask.ForeColor = Color.Black;
                buttonAddTask.BackColor = SystemColors.Control;
                buttonAddTask.ForeColor = Color.Black;
                buttonRemoveTask.BackColor = SystemColors.Control;
                buttonRemoveTask.ForeColor = Color.Black;
                btnSettings.ForeColor = Color.Black;
            }
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            Clear.Visible = false;
            checkBoxReminders.Visible = true;
            ComingSoon.Visible = true;
            Settings.Visible = true;
            Buttons.Visible = false;
            EnterTask.Visible = false;
            Task.Visible = false;
            btnCredits.Visible = false;
            btnSettings.Visible = false;
            Welcome.Visible = false;

        }

        private void checkBoxDarkMode_CheckedChanged(object sender, EventArgs e)
        {
            ToggleDarkMode(checkBoxDarkMode.Checked);
        }

        private void checkBoxTopMost_CheckedChanged(object sender, EventArgs e)
        {
            this.TopMost = this.checkBoxTopMost.Checked;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Settings.Visible = false;
            Buttons.Visible = true;
            EnterTask.Visible = true;
            Task.Visible = true;
            btnCredits.Visible = true;
            btnSettings.Visible = true;
            Welcome.Visible = true;
        }

        private void buttonClearAll_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to delete all tasks?",
                "Confirm Deletion",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
);

            if (result == DialogResult.Yes)
            {
                Tasks.Items.Clear();
                SaveTasks();
            }
        }
    }
    }
