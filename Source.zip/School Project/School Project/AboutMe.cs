﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace School_Project
{
    public partial class AboutMe : Form
    {
        public AboutMe()
        {
            InitializeComponent();
        }

        private void AboutMe_Load(object sender, EventArgs e)
        {

        }

        private void checkBoxTopMost_CheckedChanged(object sender, EventArgs e)
        {
            this.TopMost = checkBoxTopMost.Checked;
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Home newForm = new Home();
            newForm.Show();
            this.Hide();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void checkBoxDarkMode_CheckedChanged(object sender, EventArgs e)
        {
            ToggleDarkMode(checkBoxDarkMode.Checked);
        }
        private void ToggleDarkMode(bool darkMode)
        {
            if (darkMode)
            {
                this.BackColor = Color.FromArgb(45, 45, 48); // Dark gray
                label4.ForeColor = Color.White;
                label1.ForeColor = Color.White;
                label2.ForeColor = Color.White;
                label3.ForeColor = Color.White;
                btnBack.ForeColor = Color.White;
                checkBoxDarkMode.ForeColor = Color.White;
                checkBoxTopMost.ForeColor = Color.White;


            }
            else
            {
                this.BackColor = SystemColors.Control; // Light mode
                label1.ForeColor = Color.Black;
                label4.ForeColor = Color.Black;
                label2.ForeColor = Color.Black;
                label3.ForeColor = Color.Black;
                btnBack.ForeColor = Color.Black;
                checkBoxDarkMode.ForeColor = Color.Black;
                checkBoxTopMost.ForeColor = Color.Black;
            }

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            UpdateHistory newForm = new UpdateHistory();
            newForm.Show();
            this.Hide();
        }
    }
}
