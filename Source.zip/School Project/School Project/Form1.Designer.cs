﻿namespace School_Project
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.formDrag = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.formElipse = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.formBorderless = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.formAnimate = new Guna.UI2.WinForms.Guna2AnimateWindow(this.components);
            this.Tasks = new System.Windows.Forms.CheckedListBox();
            this.Task = new Guna.UI2.WinForms.Guna2Panel();
            this.EnterTask = new Guna.UI2.WinForms.Guna2Panel();
            this.textBoxNewTask = new Guna.UI2.WinForms.Guna2TextBox();
            this.Buttons = new Guna.UI2.WinForms.Guna2Panel();
            this.formShadow = new Guna.UI2.WinForms.Guna2ShadowForm(this.components);
            this.Welcome = new System.Windows.Forms.Label();
            this.btnBack = new Guna.UI2.WinForms.Guna2Button();
            this.checkBoxTopMost = new Guna.UI2.WinForms.Guna2CheckBox();
            this.checkBoxDarkMode = new Guna.UI2.WinForms.Guna2CheckBox();
            this.lblSettings = new System.Windows.Forms.Label();
            this.Clear = new Guna.UI2.WinForms.Guna2Panel();
            this.Settings = new Guna.UI2.WinForms.Guna2Panel();
            this.ComingSoon = new System.Windows.Forms.Label();
            this.checkBoxReminders = new Guna.UI2.WinForms.Guna2CheckBox();
            this.buttonClearAll = new Guna.UI2.WinForms.Guna2Button();
            this.btnCredits = new Guna.UI2.WinForms.Guna2Button();
            this.btnSettings = new Guna.UI2.WinForms.Guna2Button();
            this.buttonRemoveTask = new Guna.UI2.WinForms.Guna2Button();
            this.buttonAddTask = new Guna.UI2.WinForms.Guna2Button();
            this.Close = new Guna.UI2.WinForms.Guna2Button();
            this.Minimize = new Guna.UI2.WinForms.Guna2Button();
            this.Task.SuspendLayout();
            this.EnterTask.SuspendLayout();
            this.Buttons.SuspendLayout();
            this.Clear.SuspendLayout();
            this.Settings.SuspendLayout();
            this.SuspendLayout();
            // 
            // formDrag
            // 
            this.formDrag.DockIndicatorTransparencyValue = 0.6D;
            this.formDrag.TargetControl = this;
            this.formDrag.UseTransparentDrag = true;
            // 
            // formElipse
            // 
            this.formElipse.BorderRadius = 24;
            // 
            // formBorderless
            // 
            this.formBorderless.BorderRadius = 18;
            this.formBorderless.ContainerControl = this;
            this.formBorderless.DockIndicatorTransparencyValue = 0.6D;
            this.formBorderless.TransparentWhileDrag = true;
            // 
            // formAnimate
            // 
            this.formAnimate.AnimationType = Guna.UI2.WinForms.Guna2AnimateWindow.AnimateWindowType.AW_BLEND;
            this.formAnimate.TargetForm = this;
            // 
            // Tasks
            // 
            this.Tasks.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Tasks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Tasks.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tasks.FormattingEnabled = true;
            this.Tasks.Location = new System.Drawing.Point(8, 6);
            this.Tasks.Name = "Tasks";
            this.Tasks.Size = new System.Drawing.Size(361, 209);
            this.Tasks.TabIndex = 20;
            // 
            // Task
            // 
            this.Task.BorderColor = System.Drawing.Color.Black;
            this.Task.BorderRadius = 17;
            this.Task.BorderThickness = 2;
            this.Task.Controls.Add(this.Tasks);
            this.Task.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Task.Location = new System.Drawing.Point(15, 89);
            this.Task.Name = "Task";
            this.Task.Size = new System.Drawing.Size(377, 222);
            this.Task.TabIndex = 22;
            // 
            // EnterTask
            // 
            this.EnterTask.BorderColor = System.Drawing.Color.Black;
            this.EnterTask.BorderRadius = 18;
            this.EnterTask.BorderThickness = 2;
            this.EnterTask.Controls.Add(this.textBoxNewTask);
            this.EnterTask.ForeColor = System.Drawing.SystemColors.Desktop;
            this.EnterTask.Location = new System.Drawing.Point(15, 46);
            this.EnterTask.Name = "EnterTask";
            this.EnterTask.Size = new System.Drawing.Size(179, 40);
            this.EnterTask.TabIndex = 23;
            // 
            // textBoxNewTask
            // 
            this.textBoxNewTask.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxNewTask.DefaultText = "";
            this.textBoxNewTask.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textBoxNewTask.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textBoxNewTask.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textBoxNewTask.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textBoxNewTask.FillColor = System.Drawing.SystemColors.ButtonFace;
            this.textBoxNewTask.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textBoxNewTask.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNewTask.ForeColor = System.Drawing.Color.Black;
            this.textBoxNewTask.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textBoxNewTask.Location = new System.Drawing.Point(17, 5);
            this.textBoxNewTask.Name = "textBoxNewTask";
            this.textBoxNewTask.PlaceholderForeColor = System.Drawing.Color.Black;
            this.textBoxNewTask.PlaceholderText = "Enter Task";
            this.textBoxNewTask.SelectedText = "";
            this.textBoxNewTask.Size = new System.Drawing.Size(148, 31);
            this.textBoxNewTask.TabIndex = 0;
            // 
            // Buttons
            // 
            this.Buttons.BorderColor = System.Drawing.Color.Black;
            this.Buttons.BorderRadius = 18;
            this.Buttons.BorderThickness = 2;
            this.Buttons.Controls.Add(this.buttonRemoveTask);
            this.Buttons.Controls.Add(this.buttonAddTask);
            this.Buttons.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Buttons.Location = new System.Drawing.Point(196, 46);
            this.Buttons.Name = "Buttons";
            this.Buttons.Size = new System.Drawing.Size(104, 38);
            this.Buttons.TabIndex = 24;
            // 
            // formShadow
            // 
            this.formShadow.BorderRadius = 22;
            // 
            // Welcome
            // 
            this.Welcome.AutoSize = true;
            this.Welcome.BackColor = System.Drawing.Color.Transparent;
            this.Welcome.Font = new System.Drawing.Font("Impact", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Welcome.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Welcome.Location = new System.Drawing.Point(10, 9);
            this.Welcome.Name = "Welcome";
            this.Welcome.Size = new System.Drawing.Size(189, 34);
            this.Welcome.TabIndex = 15;
            this.Welcome.Text = "Welcome, User!";
            // 
            // btnBack
            // 
            this.btnBack.BorderRadius = 18;
            this.btnBack.BorderThickness = 2;
            this.btnBack.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnBack.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnBack.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnBack.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnBack.FillColor = System.Drawing.Color.Black;
            this.btnBack.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.Location = new System.Drawing.Point(104, 244);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(180, 45);
            this.btnBack.TabIndex = 0;
            this.btnBack.Text = " <-- Go Back";
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // checkBoxTopMost
            // 
            this.checkBoxTopMost.AutoSize = true;
            this.checkBoxTopMost.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxTopMost.CheckedState.BorderRadius = 0;
            this.checkBoxTopMost.CheckedState.BorderThickness = 0;
            this.checkBoxTopMost.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxTopMost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxTopMost.ForeColor = System.Drawing.SystemColors.Desktop;
            this.checkBoxTopMost.Location = new System.Drawing.Point(126, 92);
            this.checkBoxTopMost.Name = "checkBoxTopMost";
            this.checkBoxTopMost.Size = new System.Drawing.Size(102, 24);
            this.checkBoxTopMost.TabIndex = 28;
            this.checkBoxTopMost.Text = "Top Most";
            this.checkBoxTopMost.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxTopMost.UncheckedState.BorderRadius = 0;
            this.checkBoxTopMost.UncheckedState.BorderThickness = 0;
            this.checkBoxTopMost.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxTopMost.CheckedChanged += new System.EventHandler(this.checkBoxTopMost_CheckedChanged);
            // 
            // checkBoxDarkMode
            // 
            this.checkBoxDarkMode.AutoSize = true;
            this.checkBoxDarkMode.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxDarkMode.CheckedState.BorderRadius = 0;
            this.checkBoxDarkMode.CheckedState.BorderThickness = 0;
            this.checkBoxDarkMode.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxDarkMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxDarkMode.ForeColor = System.Drawing.SystemColors.Desktop;
            this.checkBoxDarkMode.Location = new System.Drawing.Point(126, 58);
            this.checkBoxDarkMode.Name = "checkBoxDarkMode";
            this.checkBoxDarkMode.Size = new System.Drawing.Size(115, 24);
            this.checkBoxDarkMode.TabIndex = 29;
            this.checkBoxDarkMode.Text = "Dark Mode";
            this.checkBoxDarkMode.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxDarkMode.UncheckedState.BorderRadius = 0;
            this.checkBoxDarkMode.UncheckedState.BorderThickness = 0;
            this.checkBoxDarkMode.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxDarkMode.CheckedChanged += new System.EventHandler(this.checkBoxDarkMode_CheckedChanged);
            // 
            // lblSettings
            // 
            this.lblSettings.AutoSize = true;
            this.lblSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSettings.Location = new System.Drawing.Point(113, 13);
            this.lblSettings.Name = "lblSettings";
            this.lblSettings.Size = new System.Drawing.Size(128, 33);
            this.lblSettings.TabIndex = 30;
            this.lblSettings.Text = "Settings";
            // 
            // Clear
            // 
            this.Clear.BorderColor = System.Drawing.Color.Black;
            this.Clear.BorderRadius = 18;
            this.Clear.BorderThickness = 2;
            this.Clear.Controls.Add(this.buttonClearAll);
            this.Clear.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Clear.Location = new System.Drawing.Point(302, 46);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(68, 38);
            this.Clear.TabIndex = 25;
            this.Clear.Paint += new System.Windows.Forms.PaintEventHandler(this.buttonClearAll_Paint);
            // 
            // Settings
            // 
            this.Settings.Controls.Add(this.ComingSoon);
            this.Settings.Controls.Add(this.checkBoxReminders);
            this.Settings.Controls.Add(this.lblSettings);
            this.Settings.Controls.Add(this.checkBoxDarkMode);
            this.Settings.Controls.Add(this.checkBoxTopMost);
            this.Settings.Controls.Add(this.btnBack);
            this.Settings.Location = new System.Drawing.Point(9, 46);
            this.Settings.Name = "Settings";
            this.Settings.Size = new System.Drawing.Size(391, 292);
            this.Settings.TabIndex = 21;
            // 
            // ComingSoon
            // 
            this.ComingSoon.AutoSize = true;
            this.ComingSoon.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComingSoon.Location = new System.Drawing.Point(111, 129);
            this.ComingSoon.Name = "ComingSoon";
            this.ComingSoon.Size = new System.Drawing.Size(202, 33);
            this.ComingSoon.TabIndex = 32;
            this.ComingSoon.Text = "Coming Soon";
            // 
            // checkBoxReminders
            // 
            this.checkBoxReminders.AutoSize = true;
            this.checkBoxReminders.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxReminders.CheckedState.BorderRadius = 0;
            this.checkBoxReminders.CheckedState.BorderThickness = 0;
            this.checkBoxReminders.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxReminders.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxReminders.ForeColor = System.Drawing.SystemColors.Desktop;
            this.checkBoxReminders.Location = new System.Drawing.Point(119, 170);
            this.checkBoxReminders.Name = "checkBoxReminders";
            this.checkBoxReminders.Size = new System.Drawing.Size(172, 24);
            this.checkBoxReminders.TabIndex = 31;
            this.checkBoxReminders.Text = "Reminders On/Off";
            this.checkBoxReminders.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxReminders.UncheckedState.BorderRadius = 0;
            this.checkBoxReminders.UncheckedState.BorderThickness = 0;
            this.checkBoxReminders.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // buttonClearAll
            // 
            this.buttonClearAll.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.buttonClearAll.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.buttonClearAll.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.buttonClearAll.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.buttonClearAll.FillColor = System.Drawing.Color.Transparent;
            this.buttonClearAll.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.buttonClearAll.ForeColor = System.Drawing.Color.White;
            this.buttonClearAll.Image = global::School_Project.Properties.Resources.icons8_erase_64__1_;
            this.buttonClearAll.ImageSize = new System.Drawing.Size(35, 35);
            this.buttonClearAll.Location = new System.Drawing.Point(17, 3);
            this.buttonClearAll.Name = "buttonClearAll";
            this.buttonClearAll.Size = new System.Drawing.Size(37, 32);
            this.buttonClearAll.TabIndex = 0;
            this.buttonClearAll.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // btnCredits
            // 
            this.btnCredits.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnCredits.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnCredits.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnCredits.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnCredits.FillColor = System.Drawing.Color.Transparent;
            this.btnCredits.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCredits.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btnCredits.Image = global::School_Project.Properties.Resources.icons8_creative_commons_50;
            this.btnCredits.ImageSize = new System.Drawing.Size(35, 35);
            this.btnCredits.Location = new System.Drawing.Point(13, 312);
            this.btnCredits.Name = "btnCredits";
            this.btnCredits.Size = new System.Drawing.Size(43, 40);
            this.btnCredits.TabIndex = 2;
            this.btnCredits.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSettings.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSettings.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSettings.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSettings.FillColor = System.Drawing.Color.Transparent;
            this.btnSettings.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettings.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btnSettings.Image = global::School_Project.Properties.Resources.icons8_settings_64;
            this.btnSettings.ImageSize = new System.Drawing.Size(48, 48);
            this.btnSettings.Location = new System.Drawing.Point(58, 311);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(43, 41);
            this.btnSettings.TabIndex = 26;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // buttonRemoveTask
            // 
            this.buttonRemoveTask.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.buttonRemoveTask.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.buttonRemoveTask.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.buttonRemoveTask.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.buttonRemoveTask.FillColor = System.Drawing.Color.Transparent;
            this.buttonRemoveTask.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.buttonRemoveTask.ForeColor = System.Drawing.Color.White;
            this.buttonRemoveTask.Image = global::School_Project.Properties.Resources.icons8_subtract_64;
            this.buttonRemoveTask.ImageSize = new System.Drawing.Size(30, 30);
            this.buttonRemoveTask.Location = new System.Drawing.Point(54, 3);
            this.buttonRemoveTask.Name = "buttonRemoveTask";
            this.buttonRemoveTask.Size = new System.Drawing.Size(37, 32);
            this.buttonRemoveTask.TabIndex = 1;
            this.buttonRemoveTask.Click += new System.EventHandler(this.buttonRemoveTask_Click);
            // 
            // buttonAddTask
            // 
            this.buttonAddTask.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.buttonAddTask.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.buttonAddTask.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.buttonAddTask.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.buttonAddTask.FillColor = System.Drawing.Color.Transparent;
            this.buttonAddTask.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.buttonAddTask.ForeColor = System.Drawing.Color.White;
            this.buttonAddTask.Image = global::School_Project.Properties.Resources.icons8_plus_math_64;
            this.buttonAddTask.ImageSize = new System.Drawing.Size(35, 35);
            this.buttonAddTask.Location = new System.Drawing.Point(17, 3);
            this.buttonAddTask.Name = "buttonAddTask";
            this.buttonAddTask.Size = new System.Drawing.Size(37, 32);
            this.buttonAddTask.TabIndex = 0;
            this.buttonAddTask.Click += new System.EventHandler(this.buttonAddTask_Click);
            // 
            // Close
            // 
            this.Close.Animated = true;
            this.Close.AutoRoundedCorners = true;
            this.Close.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.Close.BorderRadius = 20;
            this.Close.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Close.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Close.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Close.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Close.FillColor = System.Drawing.Color.Transparent;
            this.Close.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Close.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Close.Image = ((System.Drawing.Image)(resources.GetObject("Close.Image")));
            this.Close.ImageSize = new System.Drawing.Size(35, 35);
            this.Close.Location = new System.Drawing.Point(351, 3);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(52, 42);
            this.Close.TabIndex = 19;
            this.Close.Click += new System.EventHandler(this.guna2Button4_Click);
            // 
            // Minimize
            // 
            this.Minimize.Animated = true;
            this.Minimize.AutoRoundedCorners = true;
            this.Minimize.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.Minimize.BorderRadius = 20;
            this.Minimize.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Minimize.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Minimize.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Minimize.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Minimize.FillColor = System.Drawing.Color.Transparent;
            this.Minimize.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Minimize.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Minimize.Image = ((System.Drawing.Image)(resources.GetObject("Minimize.Image")));
            this.Minimize.ImageSize = new System.Drawing.Size(30, 30);
            this.Minimize.Location = new System.Drawing.Point(299, 3);
            this.Minimize.Name = "Minimize";
            this.Minimize.Size = new System.Drawing.Size(52, 42);
            this.Minimize.TabIndex = 18;
            this.Minimize.Click += new System.EventHandler(this.guna2Button5_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(412, 351);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Task);
            this.Controls.Add(this.btnCredits);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.Buttons);
            this.Controls.Add(this.EnterTask);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.Minimize);
            this.Controls.Add(this.Welcome);
            this.Controls.Add(this.Settings);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Task.ResumeLayout(false);
            this.EnterTask.ResumeLayout(false);
            this.Buttons.ResumeLayout(false);
            this.Clear.ResumeLayout(false);
            this.Settings.ResumeLayout(false);
            this.Settings.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI2.WinForms.Guna2DragControl formDrag;
        private Guna.UI2.WinForms.Guna2Elipse formElipse;
        private Guna.UI2.WinForms.Guna2BorderlessForm formBorderless;
        private Guna.UI2.WinForms.Guna2AnimateWindow formAnimate;
        private Guna.UI2.WinForms.Guna2Button Close;
        private Guna.UI2.WinForms.Guna2Button Minimize;
        private System.Windows.Forms.CheckedListBox Tasks;
        private Guna.UI2.WinForms.Guna2Panel Buttons;
        private Guna.UI2.WinForms.Guna2Panel EnterTask;
        private Guna.UI2.WinForms.Guna2Panel Task;
        private Guna.UI2.WinForms.Guna2ShadowForm formShadow;
        private Guna.UI2.WinForms.Guna2Button buttonRemoveTask;
        private Guna.UI2.WinForms.Guna2Button buttonAddTask;
        private Guna.UI2.WinForms.Guna2Button btnCredits;
        private Guna.UI2.WinForms.Guna2TextBox textBoxNewTask;
        private Guna.UI2.WinForms.Guna2Button btnSettings;
        private System.Windows.Forms.Label Welcome;
        private Guna.UI2.WinForms.Guna2Panel Clear;
        private Guna.UI2.WinForms.Guna2Button buttonClearAll;
        private Guna.UI2.WinForms.Guna2Panel Settings;
        private System.Windows.Forms.Label lblSettings;
        private Guna.UI2.WinForms.Guna2CheckBox checkBoxDarkMode;
        private Guna.UI2.WinForms.Guna2CheckBox checkBoxTopMost;
        private Guna.UI2.WinForms.Guna2Button btnBack;
        private Guna.UI2.WinForms.Guna2CheckBox checkBoxReminders;
        private System.Windows.Forms.Label ComingSoon;
    }
}

