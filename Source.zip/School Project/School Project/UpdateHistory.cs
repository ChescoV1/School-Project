﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_Project
{
    public partial class UpdateHistory : Form
    {
        public UpdateHistory()
        {
            InitializeComponent();
        }

        private void guna2Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AboutMe newForm = new AboutMe();
            newForm.Show();
            this.Hide();
        }

        private void checkBoxDarkMode_CheckedChanged(object sender, EventArgs e)
        {
            ToggleDarkMode(checkBoxDarkMode.Checked);
        }
        private void ToggleDarkMode(bool darkMode)
        {
            if (darkMode)
            {
                Welcome.ForeColor = Color.White;
                this.BackColor = Color.FromArgb(45, 45, 48); // Dark gray
                label4.ForeColor = Color.White;
                label1.ForeColor = Color.White;
                label2.ForeColor = Color.White;
                label3.ForeColor = Color.White;
                btnBack.ForeColor = Color.White;
                checkBoxDarkMode.ForeColor = Color.White;
                checkBoxTopMost.ForeColor = Color.White;


            }
            else
            {
                this.BackColor = SystemColors.Control; // Light mode
                Welcome.ForeColor = Color.Black;
                label1.ForeColor = Color.Black;
                label4.ForeColor = Color.Black;
                label2.ForeColor = Color.Black;
                label3.ForeColor = Color.Black;
                checkBoxDarkMode.ForeColor = Color.Black;
                checkBoxTopMost.ForeColor = Color.Black;
            }

        }

        private void checkBoxTopMost_CheckedChanged(object sender, EventArgs e)
        {
            this.TopMost = checkBoxTopMost.Checked;
        }

        private void Minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        }
    }
